find src -name '*.cpp' -or -name '*.h' | xargs clang-format -i
